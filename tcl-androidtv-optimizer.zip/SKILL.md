---
name: tcl-androidtv-optimizer
description: Guide users through backing up, debloating, optimizing, and configuring Projectivy Launcher as the native default home screen on Android TV and Google TV devices via ADB. Use when the user asks to optimize, debloat, speed up, or configure a TCL TV, Android TV, or Google TV, set up Projectivy Launcher over ADB, or generate ADB optimization and rollback scripts.
---

# TCL Android TV Optimizer

Provide a terminal-driven, non-root ADB workflow to back up, debloat, optimize, and configure Projectivy Launcher as the native default home screen on low-RAM Android TV and Google TV devices.

## When to Use

- The user wants to debloat, speed up, or optimize a TCL TV, Android TV, or Google TV device over ADB.
- The user wants to set Projectivy Launcher (`com.spocky.projengmenu`) as the native default launcher without keeping the stock launcher in memory.
- The user asks for an interactive step-by-step ADB optimization session or wants the automated PowerShell optimization and rollback scripts (`Optimize-TCLTV.ps1` and `Restore-Defaults.ps1`, stored in `references/powershell-scripts.md`).

## Steps

### 1. Gather Context and Intake

Ask the user for their setup details before issuing ADB modification commands:

1. Host computer operating system (Windows PowerShell, macOS, or Linux).
2. Whether Network/USB Debugging is enabled in Developer Options and the TV's local IP address.
3. Device RAM capacity (2GB budget chassis vs. higher RAM).
4. Whether wireless screen mirroring (Miracast) is used or should be disabled to save memory.
5. Whether Projectivy Launcher (`com.spocky.projengmenu`) is already installed or needs to be sideloaded from an APK.
6. Whether they want an interactive one-step-at-a-time terminal walkthrough or the complete automated PowerShell scripts (`Optimize-TCLTV.ps1` and `Restore-Defaults.ps1`).

Wait for the user's answers. During an interactive walkthrough, give only one logical step per turn, explain what expected output to verify, and wait for confirmation before proceeding.

### 2. Connect Over ADB

Verify `adb` is available (`winget install Google.PlatformTools` on Windows or `brew install android-platform-tools` on macOS) and connect to the TV:

```powershell
adb connect <TV_IP>:5555
adb devices
```

Remind the user to check "Always allow from this computer" on the TV screen when the RSA prompt appears.

### 3. Capture a Mandatory Pre-Optimization Backup

Before modifying any packages, roles, or settings, export the TV's untouched initial state to `./backups/tv_initial_state_<timestamp>.txt`. Keep these exact section headers so `Restore-Defaults.ps1` can parse the file automatically:

1. `--- CURRENT HOME ROLE HOLDER ---`: output of `adb shell cmd role get-role-holders android.app.role.HOME`
2. `--- ENABLED PACKAGES ---`: output of `adb shell pm list packages -e`
3. `--- ALREADY DISABLED PACKAGES ---`: output of `adb shell pm list packages -d`
4. `--- GLOBAL SETTINGS ---`: output of `adb shell settings list global`
5. `--- SECURE SETTINGS ---`: output of `adb shell settings list secure`
6. `--- BASELINE MEMORY SNAPSHOT ---`: output of `adb shell dumpsys meminfo --package-summary`

Inspect the active third-party packages (`adb shell pm list packages -3 -e`), OEM packages, and active input method (`adb shell settings get secure default_input_method`) from this snapshot to tailor subsequent steps dynamically.

### 4. Configure Projectivy Launcher as the Native Default

Grant Projectivy required permissions, whitelist it from Doze so Android never purges it from RAM, append its Accessibility Service without overwriting existing services, assign it the native `HOME` role, and disable stock launchers:

```powershell
adb shell pm grant com.spocky.projengmenu android.permission.READ_EXTERNAL_STORAGE
adb shell pm grant com.spocky.projengmenu android.permission.WRITE_EXTERNAL_STORAGE
adb shell pm grant com.spocky.projengmenu android.permission.WRITE_SECURE_SETTINGS
adb shell appops set com.spocky.projengmenu SYSTEM_ALERT_WINDOW allow
adb shell appops set com.spocky.projengmenu AUTO_START allow
adb shell appops set com.spocky.projengmenu BIND_ACCESSIBILITY_SERVICE allow
adb shell dumpsys deviceidle whitelist +com.spocky.projengmenu
adb shell cmd role add-role-holder --user 0 android.app.role.HOME com.spocky.projengmenu
```

Disable the stock launchers present on the device (`com.google.android.apps.tv.launcherx`, `com.google.android.tvlauncher`, `com.google.android.tungsten.setupwraith`, `com.tcl.waterfall`, `com.tcl.cyberui`) using `adb shell pm disable-user --user 0 <pkg>`.

### 5. Disable Safe OEM Telemetry and Bloatware

Cross-reference the device's enabled packages against known safe-to-disable OEM telemetry services and disable only those present on the TV:

- `com.tcl.logman`, `com.tcl.report`, `com.tcl.diagnostics`, `com.tcl.factory.view`
- `com.tcl.xian.beva`, `com.tcl.useragreement`, `com.tcl.messagebox`, `com.tcl.versionUpdateApp`
- `com.tcl.assistant`, `com.tcl.autopair`, `com.tcl.bi`, `com.tcl.notereminder`, `com.tcl.bootadservice`
- `com.tcl.miracast` (only if the user opted to disable wireless casting)

### 6. Tune Memory, Animations, Radios, and Play Store Updates

Apply global settings to reduce frame latency, stop background radio polling, cap cached processes on 2GB RAM devices, and stop Google Play Store background auto-updates from overwriting compiled binaries:

```powershell
adb shell settings put global window_animation_scale 0.5
adb shell settings put global transition_animation_scale 0.5
adb shell settings put global animator_duration_scale 0.5
adb shell settings put global package_verifier_enable 0
adb shell settings put global standard_max_cached_processes 2
adb shell settings put global max_cached_processes 2
adb shell settings put global wifi_scan_always_enabled 0
adb shell settings put global ble_scan_always_enabled 0
adb shell settings put global captive_portal_mode 0
adb shell cmd appops set com.android.vending RUN_IN_BACKGROUND ignore
```

### 7. Restrict Streaming App Background Activity and Compile with AOT

For discovered streaming and user apps (excluding Projectivy, active keyboards, and accessibility services):

1. Run `adb shell cmd appops set <pkg> RUN_IN_BACKGROUND ignore`.
2. Run `adb shell cmd appops set <pkg> WAKE_LOCK ignore` on secondary streaming apps, exempting cast/media server apps (`com.netflix.ninja`, `com.google.android.youtube.tv`, `com.google.android.youtube.tvmusic`, `com.plexapp.android`, `org.xbmc.kodi`).
3. Pre-compile Projectivy and all target streaming apps into native machine code using `adb shell cmd package compile -m speed-profile -f <pkg>`.
4. Launch Projectivy (`adb shell monkey -p com.spocky.projengmenu 1`) and compare `adb shell dumpsys meminfo --package-summary` against the baseline snapshot.

## Gotchas

- **Never disable critical TV hardware packages:** Always keep `com.tcl.tvinput`, `com.tcl.tv`, `com.tcl.settings`, `com.tcl.systemserver`, and `com.android.tv.settings` enabled so HDMI-CEC, picture settings, and hardware inputs continue working.
- **Protect keyboards and button mappers:** Never apply `RUN_IN_BACKGROUND ignore` to packages listed in `default_input_method` or `enabled_accessibility_services`, as doing so breaks custom keyboards and remote button remappers.
- **Preserve existing accessibility services:** Read `enabled_accessibility_services` first and append `com.spocky.projengmenu/com.spocky.projengmenu.services.ProjectivyAccessibilityService` with a colon separator (`:`) if other services are active.
- **Do not re-enable factory-disabled stubs on rollback:** When rolling back changes, parse `--- ALREADY DISABLED PACKAGES ---` from the earliest backup snapshot so regional carrier stubs disabled at the factory remain disabled.
